import pygame
from Canvas_Settings import *
from Shop import *
from Player import *
from Opponent import *
from os import path
import os
import random


class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()

        self.category_text = pygame.font.SysFont('Arial', 40, False, False)
        self.general_text = pygame.font.SysFont('Arial', 30, False, False)

        self.clock = pygame.time.Clock()

        self.screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))

        self.run = True
        self.title_screen = True
        self.plot = False
        self.shopping = False
        self.combat = False

        self.number_of_battles = 0  # max battles against standard opponents is 10 Afterwards you face the B0SS
        self.player_level = 1
        self.opponent_level = 1
        self.opponent = Opponent(self.opponent_level)

        # Starting stat values for player Transfer to player constructor for battle
        self.max_life = 100
        self.max_mana = 10

        self.player_EXP = 0
        self.player_max_EXP = self.player_level ** 2

        self.strength = 1
        self.dexterity = 1
        self.magic = 1
        self.vitality = 1

        self.minimum_damage = 5
        self.maximum_damage = 10

        self.spell_minimum_damage = 5
        self.spell_maximum_damage = 10



        self.turns = 2  # 0 = player turn / 1 = opponents turn / 2 not in battle
        # set of boolean flags for purchasing equipemnt and spells
        self.buy_wep_A = False
        self.buy_wep_B = False
        self.buy_off_spell = False
        self.buy_def_spell = False

        self.santho_fight = False
        self.santho_win = False

        # Set of combat boolean flags
        self.turn_made = False  # flag indicating a turn has been made
        self.attack = False
        self.defense_mode = False  # Flag to indicate the player is defending from attack reducing damage taken by %50
        self.cast_offense = False
        self.cast_defense = False

        self.off_spell_list = ["Fireball", "Icebolt", "Lightning bolt", "Apocolypse"]
        self.def_spell_list = ["Heal", "Weaken", "Might", "Guardian shield"]

    # ------------------------------------------------------------------------------------------------------------------
    # Events segments

    def starting_values(self):
        self.player_level = 1
        self.max_life = 100
        self.max_mana = 10

        self.player_EXP = 0
        self.player_max_EXP = self.player_level ** 2

        self.strength = 1
        self.dexterity = 1
        self.magic = 1
        self.vitality = 1

        self.opponent_level = 1

        self.minimum_damage = 1
        self.maximum_damage = 3

        self.spell_minimum_damage = 2
        self.spell_maximum_damage = 4

        self.number_of_battles = 0
        self.weapon = Weapons()

        self.off_spell = Spells()
        self.def_spell = Spells()

        self.santho_fight = False

    def eventhandle(self):
        self.clock.tick(30)  # 30 FPS
        if self.title_screen:
            self.title_events()
        if self.shopping:
            self.shop_events()
        if self.combat:
            self.combat_events()

    # ------------------------------------------------------------------------------------------------------------------
    # Series of events handled in title screen
    def title_events(self):
        click = pygame.mouse.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.run = False
                self.title_screen = False

            if event.type == pygame.MOUSEBUTTONDOWN and not self.plot:
                self.plot = True
                self.plotbackground()

            elif event.type == pygame.MOUSEBUTTONDOWN and self.plot:
                self.title_screen = False
                self.plot = False
                self.starting_values()
                self.shopbackground()
                self.shopping = True

    # ------------------------------------------------------------------------------------------------------------------
    # Series of event handled in the Shop portion of the game.
    # Sub sections purchases will be handled in various functions
    def shop_events(self):
        click = pygame.mouse.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.run = False
                self.shopping = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                print(x, y)
                # this if Checks if player decides to go to battle
                if 440 < x < 833 and 606 < y < 680:
                    self.shopping = False
                    self.player = Player(self.player_level, self.player_EXP, self.player_max_EXP,
                                         self.max_life, self.max_mana, self.strength, self.dexterity,
                                         self.magic, self.vitality, self.spell_minimum_damage,
                                         self.spell_maximum_damage, self.minimum_damage, self.maximum_damage)
                    if self.player_level == 10 or self.number_of_battles == 50:
                        self.opponent = Santho(self.player.level)
                        self.santho_fight = True
                    else:
                        self.opponent = Opponent(self.opponent_level)
                    self.turn_made = False
                    self.combatbackground()
                    self.turns = 0
                    self.combat = True
                    self.buy_wep_A = False
                    self.buy_wep_B = False
                    self.buy_off_spell = False
                    self.buy_def_spell = False

                # Checks if player is purchasing weapons
                if 515 < x < 808 and 154 < y < 267:
                    if self.buy_wep_A:
                        print("You already bought your weapon item")
                    else:
                        self.buy_wep_A = True
                        self.purchasing_equipment()
                        self.buy_wep_B = True
                if 515 < x < 808 and 286 < y < 399:
                    if self.buy_wep_B:
                        print("You already bought your weapon item")
                    else:
                        self.buy_wep_B = True
                        self.purchasing_equipment()
                        self.buy_wep_A = True
                # Checks if player is purchasing spells
                if 160 < x < 463 and 366 < y < 430:
                    if self.buy_off_spell:
                        print("you already bought a spell for this session")
                    else:
                        self.buy_off_spell = True
                        self.purchasing_spells()
                        self.buy_def_spell = True

                if 160 < x < 463 and 457 < y < 532:
                    if self.buy_def_spell:
                        print("you already bought a spell for this session")
                    else:
                        self.buy_def_spell = True
                        self.purchasing_spells()
                        self.buy_off_spell = True

                # checks if player has bought strength
                if 145 < x < 295 and 139 < y < 199:
                    self.purchasing_stats("s")
                # checks if player has bought dexterity
                if 305 < x < 455 and 139 < y < 199:
                    self.purchasing_stats("d")
                if 145 < x < 295 and 209 < y < 271:
                    self.purchasing_stats("m")
                if 305 < x < 455 and 209 < y < 271:
                    self.purchasing_stats("v")

                # this section adjusts the opponents level
                if 130 < x < 180 and 645 < y < 677:
                    self.opponent_level += 1
                    self.shopbackground()
                if 200 < x < 250 and 645 < y < 677:
                    if self.opponent_level > 1:
                        self.opponent_level -= 1
                        self.shopbackground()

    def purchasing_stats(self, x):
        if x == "s":
            if self.max_life > 1:
                self.strength += 1
                self.max_life -= 10
                self.shopbackground()
        elif x == "d":
            if self.max_life > 1:
                self.dexterity += 1
                self.max_life -= 10
                self.shopbackground()
        elif x == "m":
            if self.max_life > 10:
                self.magic += 1
                self.max_life -= 10
                self.shopbackground()
        elif x == "v":
            if self.max_life > 2:
                self.vitality += 1
                self.max_life -= 2
                self.shopbackground()

    def purchasing_equipment(self):
        if self.weapon.purchase_check(self.player_level, self.max_life, self.buy_wep_A, self.buy_wep_B):
            self.minimum_damage = self.weapon.minimum_damage
            self.maximum_damage = self.weapon.maximum_damage
            self.max_life -= self.weapon.cost
            self.shopbackground()

    def purchasing_spells(self):
        if self.off_spell.purchase_check(self.player_level, self.max_life, self.buy_off_spell, self.buy_def_spell):
            if self.buy_off_spell:
                self.spell_minimum_damage = self.off_spell.spell_min_damage
                self.spell_maximum_damage = self.off_spell.spell_max_damage
                self.max_life -= self.off_spell.spell_life_cost

        if self.def_spell.purchase_check(self.player_level, self.max_life, self.buy_off_spell, self.buy_def_spell):
            if self.buy_def_spell:
                # Put something there soon
                self.max_life -= self.def_spell.spell_life_cost

        self.shopbackground()

    # ------------------------------------------------------------------------------------------------------------------
    # Series of events handled in the combat section Will have sub sections separated by Players and Opponents actions

    def combat_events(self):
        click = pygame.mouse.get_pressed()
        # cursor = pygame.mouse.get_cursor()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.run = False
                self.combat = False

            if event.type == pygame.MOUSEBUTTONDOWN and (self.opponent.life > 0 and self.player.life > 0):

                x, y = pygame.mouse.get_pos()
                print(x, y)
                # -------------------------------------------------------------------------------
                # Click segment for striking an opponent with your weapon or fists AND clicking next
                if 150 < x < 385 and 540 < y < 626:
                    if self.turns == 0:
                        self.player_attacks()

                    elif self.turns == 1:
                        self.opponent_attacks()

                # Click segment for Defending an attack
                if 405 < x < 635 and 540 < y < 626:
                    if self.turns == 0:
                        self.defend_attack()
                # Click segment for casting an offensive spell
                if 665 < x < 895 and 540 < y < 626:
                    if self.turns == 0:
                        self.player_cast_offense()
                # Click segment for casting a defensive spell
                if 915 < x < 1145 and 540 < y < 626:
                    pass

            # After end of combat If player is the victor
            elif event.type == pygame.MOUSEBUTTONDOWN and self.opponent.life <= 0:
                if self.santho_fight:
                    self.titlebackground()
                    self.combat = False
                    self.title_screen = True
                    self.turns = 2
                else:
                    x, y = pygame.mouse.get_pos()
                    if 150 < x < 385 and 540 < y < 626:
                        self.shopbackground()
                        self.combat = False
                        self.shopping = True
                        self.turns = 2
            # After end of combat if the opponent is the victor
            elif event.type == pygame.MOUSEBUTTONDOWN and self.player.life <= 0:
                x, y = pygame.mouse.get_pos()
                if 150 < x < 385 and 540 < y < 626:
                    self.titlebackground()
                    self.combat = False
                    self.title_screen = True
                    self.turns = 2
                # -------------------------------------------------------------------------------

    def player_attacks(self):
        self.player.damage = random.randrange(self.player.minimum_damage, self.player.maximum_damage)
        self.opponent.life -= self.player.damage
        self.attack = True
        self.turn_made = True
        self.combatbackground()
        self.attack = False
        self.turns = 1

    def defend_attack(self):
        self.defense_mode = True

        self.turn_made = True
        self.combatbackground()
        self.turns = 1

    def player_cast_offense(self):
        self.player.spell_damage = random.randrange(self.player.spell_min_damage, self.player.spell_max_damage)
        self.opponent.life -= self.player.spell_damage
        self.cast_offense = True
        self.turn_made = True
        self.combatbackground()
        self.cast_offense = False
        self.turns = 1

    def player_cast_defense(self):
        pass

    def opponent_attacks(self):
        if self.defense_mode:
            self.opponent.damage = random.randrange(self.opponent.minimum_damage, self.opponent.maximum_damage) / 2
            self.defense_mode = False
        else:
            self.opponent.damage = random.randrange(self.opponent.minimum_damage, self.opponent.maximum_damage)

        self.player.life -= self.opponent.damage

        self.turn_made = False
        self.combatbackground()
        self.turns = 0

    # ------------------------------------------------------------------------------------------------------------------
    # Background drawing segment

    def titlebackground(self):

        image = pygame.image.load(os.path.join("Background_Images", "Horribly drawn title screen.png")).convert()
        self.screen.blit(image, (0, 0))
        pygame.display.update()

    def plotbackground(self):
        image = pygame.image.load(os.path.join("Background_Images", "OMG theres plot.png")).convert()
        self.screen.blit(image, (0, 0))
        pygame.display.update()

    def shopbackground(self):

        image = pygame.image.load(os.path.join("Background_Images", "Crudely drawn shop screen.png")).convert()
        self.screen.blit(image, (0, 0))

        text = self.category_text.render("Player stats", True, WHITE)
        self.screen.blit(text, (920, 40))

        text = self.category_text.render("Number of battles won: " + str(self.number_of_battles), True, WHITE)
        self.screen.blit(text, (400, 20))

        text = self.general_text.render("Current Level: " + str(self.player_level), True, WHITE)
        self.screen.blit(text, (920, 100))

        text = self.general_text.render("Exp: " + str(self.player_EXP) + "/" + str(self.player_max_EXP), True, WHITE)
        self.screen.blit(text, (920, 140))

        text = self.general_text.render("Max life: " + str(self.max_life), True, WHITE)
        self.screen.blit(text, (920, 180))

        text = self.general_text.render("Max mana: " + str(self.max_mana), True, WHITE)
        self.screen.blit(text, (920, 220))

        text = self.general_text.render("Strength: " + str(self.strength), True, WHITE)
        self.screen.blit(text, (920, 280))

        text = self.general_text.render("Dexterity: " + str(self.dexterity), True, WHITE)
        self.screen.blit(text, (920, 320))

        text = self.general_text.render("Magic: " + str(self.magic), True, WHITE)
        self.screen.blit(text, (920, 360))

        text = self.general_text.render("Vitality: " + str(self.vitality), True, WHITE)
        self.screen.blit(text, (920, 400))

        # This text indicated opponents level it can be adjusted prior to battle.
        text = self.general_text.render(str(self.opponent_level), True, RED)
        self.screen.blit(text, (305, 608))

        # Shop updates list of available weapons and spells to purchase based on player level
        if self.player_level < 3:
            text = self.general_text.render("Buy dagger ", True, WHITE)
            self.screen.blit(text, (524, 150))
            text = self.general_text.render("Base Damage: 2-4", True, WHITE)
            self.screen.blit(text, (524, 190))
            text = self.general_text.render("Cost: 10 Max Life", True, WHITE)
            self.screen.blit(text, (524, 230))

            text = self.general_text.render("Buy short sword ", True, WHITE)
            self.screen.blit(text, (524, 285))
            text = self.general_text.render("Base Damage: 4-8", True, WHITE)
            self.screen.blit(text, (524, 325))
            text = self.general_text.render("Cost: 15 Max Life", True, WHITE)
            self.screen.blit(text, (524, 365))

            text = self.general_text.render("Buy Fireball: 20-30 dmg", True, WHITE)
            self.screen.blit(text, (165, 370))
            text = self.general_text.render("Cost: 20 Max Life", True, WHITE)
            self.screen.blit(text, (165, 400))

            text = self.general_text.render("Buy Heal: recover 40% life", True, WHITE)
            self.screen.blit(text, (165, 460))
            text = self.general_text.render("Cost: 20 Max Life", True, WHITE)
            self.screen.blit(text, (165, 490))

        elif self.player_level < 5:
            text = self.general_text.render("buy long sword", True, WHITE)
            self.screen.blit(text, (524, 150))
            text = self.general_text.render("Base Damage: 6-16", True, WHITE)
            self.screen.blit(text, (524, 190))
            text = self.general_text.render("Cost: 50 Max Life", True, WHITE)
            self.screen.blit(text, (524, 230))

            text = self.general_text.render("Buy mage staff", True, WHITE)
            self.screen.blit(text, (524, 285))
            text = self.general_text.render("Base Damage: 7-11", True, WHITE)
            self.screen.blit(text, (524, 325))
            text = self.general_text.render("Cost: 75 Max Life", True, WHITE)
            self.screen.blit(text, (524, 365))

            text = self.general_text.render("Buy ice bolt: 15-25 dmg", True, WHITE)
            self.screen.blit(text, (165, 370))
            text = self.general_text.render("Cost: 50 Max Life", True, WHITE)
            self.screen.blit(text, (165, 400))

            text = self.general_text.render("Buy Weaken: reduce enemy damage 50%", True, WHITE)
            self.screen.blit(text, (165, 460))
            text = self.general_text.render("Cost: 60 Max Life", True, WHITE)
            self.screen.blit(text, (165, 490))

        elif self.player_level < 7:
            text = self.general_text.render("Buy Mace", True, WHITE)
            self.screen.blit(text, (524, 150))
            text = self.general_text.render("Base Damage: 10-20", True, WHITE)
            self.screen.blit(text, (524, 190))
            text = self.general_text.render("Cost: 150 Max Life", True, WHITE)
            self.screen.blit(text, (524, 230))

            text = self.general_text.render("Buy sorcerer staff", True, WHITE)
            self.screen.blit(text, (524, 285))
            text = self.general_text.render("Base Damage: 9-14", True, WHITE)
            self.screen.blit(text, (524, 325))
            text = self.general_text.render("Cost: 125 Max Life", True, WHITE)
            self.screen.blit(text, (524, 365))

            text = self.general_text.render("Buy lightning bolt: 1-50 dmg", True, WHITE)
            self.screen.blit(text, (165, 370))
            text = self.general_text.render("Cost: 150 Max Life", True, WHITE)
            self.screen.blit(text, (165, 400))

            text = self.general_text.render("Buy Might: increase player damage 50%", True, WHITE)
            self.screen.blit(text, (165, 460))
            text = self.general_text.render("Cost: 100 Max Life", True, WHITE)
            self.screen.blit(text, (165, 490))

        elif self.player_level < 10:
            text = self.general_text.render("Buy battle axe", True, WHITE)
            self.screen.blit(text, (524, 150))
            text = self.general_text.render("Base Damage: 20-30", True, WHITE)
            self.screen.blit(text, (524, 190))
            text = self.general_text.render("Cost: 300 Max Life", True, WHITE)
            self.screen.blit(text, (524, 230))

            text = self.general_text.render("Buy wizard staff", True, WHITE)
            self.screen.blit(text, (524, 285))
            text = self.general_text.render("Base Damage: 14-22", True, WHITE)
            self.screen.blit(text, (524, 325))
            text = self.general_text.render("Cost: 250 Max Life", True, WHITE)
            self.screen.blit(text, (524, 365))

            text = self.general_text.render("Buy Guardian shield: reduce damage 75%", True, WHITE)
            self.screen.blit(text, (165, 460))
            text = self.general_text.render("Cost: 250 Max Life", True, WHITE)
            self.screen.blit(text, (165, 490))

        elif self.player_level == 10:
            text = self.general_text.render("Buy Astral Blade", True, WHITE)
            self.screen.blit(text, (524, 150))
            text = self.general_text.render("Base Damage: 40-100", True, WHITE)
            self.screen.blit(text, (524, 190))
            text = self.general_text.render("Cost: 1500 Max Life", True, WHITE)
            self.screen.blit(text, (524, 230))

            text = self.general_text.render("Buy Archmage staff", True, WHITE)
            self.screen.blit(text, (524, 285))
            text = self.general_text.render("Base Damage: 25-50", True, WHITE)
            self.screen.blit(text, (524, 325))
            text = self.general_text.render("Cost: 1000 Max Life", True, WHITE)
            self.screen.blit(text, (524, 365))

            text = self.general_text.render("Buy Apocolypse: 50-75 dmg", True, WHITE)
            self.screen.blit(text, (165, 370))
            text = self.general_text.render("Cost: 500 Max Life", True, WHITE)
            self.screen.blit(text, (165, 400))


        pygame.display.update()

    def combatbackground(self):
        image = pygame.image.load(os.path.join("Background_Images", "ShoddyCombatScreen.png")).convert()
        self.screen.blit(image, (0, 0))

        # If player strikes the opponent in combat
        if self.turns == 0:
            if self.attack:
                text = self.general_text.render("you strike at the opponent for " + str(self.player.damage) +
                                                " damage!", True, WHITE)
                self.screen.blit(text, (250, 140))
                if self.opponent.life <= 0:
                    if self.santho_fight:
                        text = self.general_text.render(
                            "YOU HAVE WON! Santho Has been defeated and you have earned your freedom!",
                            True, WHITE)
                        self.screen.blit(text, (250, 180))
                    else:
                        text = self.general_text.render(
                            "You won the battle and have earned " + str(self.opponent_level) + " Experience!",
                            True, WHITE)
                        self.screen.blit(text, (250, 180))
                        self.number_of_battles += 1
                        self.player_EXP += self.opponent_level
                        if self.player_EXP >= self.player_max_EXP:
                            self.player_EXP -= self.player_max_EXP
                            self.max_life += (self.vitality * self.player.level)
                            self.max_mana += (self.magic * self.player.level)
                            self.player_level += 1
                            self.player_max_EXP = self.player_level ** 2
                            text = self.general_text.render(
                                "LEVEL UP! You gained " + str(self.vitality * self.player.level)
                                + " Max life and " + str(self.magic * self.player.level) +
                                " max mana", True, WHITE)
                            self.screen.blit(text, (250, 220))

                        text = self.general_text.render("click next to rest up and return to shop", True, WHITE)
                        self.screen.blit(text, (250, 260))

            if self.defense_mode:
                text = self.general_text.render("You've taken a defensive stance for this round", True, WHITE)
                self.screen.blit(text, (250, 140))
                text = self.general_text.render("Incoming damage will be reduced by 50%", True, WHITE)
                self.screen.blit(text, (250, 180))

            if self.cast_offense:
                text = self.general_text.render("you cast a deadly spell for " + str(self.player.spell_damage) +
                                                " damage!", True, WHITE)
                self.screen.blit(text, (250, 140))
                if self.opponent.life <= 0:
                    if self.santho_fight:
                        text = self.general_text.render("YOU HAVE WON! Santho Has been defeated.", True, WHITE)
                        self.screen.blit(text, (250, 180))

                        text = self.general_text.render("You have earned your freedom!", True, WHITE)
                        self.screen.blit(text, (250, 180))
                    else:
                        text = self.general_text.render(
                            "You won the battle and have earned " + str(self.opponent_level) + " Experience!",
                            True, WHITE)
                        self.screen.blit(text, (250, 180))
                        self.number_of_battles += 1
                        self.player_EXP += self.opponent_level
                        if self.player_EXP >= self.player_max_EXP:
                            self.player_EXP -= self.player_max_EXP
                            self.max_life += (self.vitality * self.player.level)
                            self.max_mana += (self.magic * self.player.level)
                            self.player_level += 1
                            self.player_max_EXP = self.player_level ** 2
                            text = self.general_text.render(
                                "LEVEL UP! You gained " + str(self.vitality * self.player.level)
                                + " Max life and " + str(self.magic * self.player.level) +
                                " max mana", True, WHITE)
                            self.screen.blit(text, (250, 220))

                        text = self.general_text.render("click next to rest up and return to shop", True, WHITE)
                        self.screen.blit(text, (250, 260))

            if self.cast_defense:
                pass

        # If opponent strikes the player in combat
        if self.turns == 1:
            text = self.general_text.render("your opponent strikes you for " + str(self.opponent.damage) + " damage!",
                                            True, WHITE)
            self.screen.blit(text, (250, 140))
            if self.player.life <= 0:
                text = self.general_text.render("You Perished!", True, WHITE)
                self.screen.blit(text, (250, 180))

        # players life and mana
        text = self.general_text.render("Life: " + str(self.player.life), True, WHITE)
        self.screen.blit(text, (35, 150))
        text = self.general_text.render("Mana: " + str(self.player.mana), True, WHITE)
        self.screen.blit(text, (35, 190))

        # opponents life and mana
        text = self.general_text.render("Life: " + str(self.opponent.life), True, WHITE)
        self.screen.blit(text, (1050, 150))
        text = self.general_text.render("Mana: " + str(self.opponent.mana), True, WHITE)
        self.screen.blit(text, (1050, 190))

        if not self.turn_made and self.player.life > 0:
            # Combat buttons text
            text = self.category_text.render("Strike enemy      Defend Attack       Cast offense       Cast defense",
                                             True, WHITE)
            self.screen.blit(text, (175, 550))

        if self.turn_made or self.player.life <= 0:
            # After player makes his/her turn or player has won or lost the battle
            text = self.category_text.render("Next", True, WHITE)
            self.screen.blit(text, (175, 550))

        pygame.display.update()

    # ------------------------------------------------------------------------------------------------------------------
    # game state running segments
    def running(self):
        while self.title_screen:
            self.eventhandle()
        while self.shopping:
            self.eventhandle()
        while self.combat:
            self.eventhandle()
    # ------------------------------------------------------------------------------------------------------------------


# Class ends


game = Game()
game.titlebackground()

while game.run:
    game.running()

pygame.quit()

# Save this snippet of commented code for future use
# MAKE IT SO if cursor hovers over something it highlights
#   x, y = pygame.mouse.get_pos()
#   print(x, y)
# Click events for combat
