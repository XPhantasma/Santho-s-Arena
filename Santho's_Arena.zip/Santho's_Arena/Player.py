import random


class Player:
    def __init__(self, lv, exp, max_exp, life, mana, st, de, en, vt, Smin, Smax, wmin, wmax):
        self.level = lv
        self.xp = exp
        self.max_xp = max_exp

        self.maxlife = life
        self.life = self.maxlife
        self.maxmana = mana
        self.mana = self.maxmana

        self.strength = st
        self.dexterity = de
        self.magic = en
        self.vitality = vt

        weapon_min = wmin
        weapon_max = wmax

        spell_min = Smin
        spell_max = Smax

        self.spell_min_damage = int(spell_min * self.level * (1 + self.magic/10))
        self.spell_max_damage = int(spell_max * self.level * (1 + self.magic/10))
        self.spell_damage = random.randrange(self.spell_min_damage, self.spell_max_damage)

        self.minimum_damage = int(weapon_min * (1 + ((self.strength + self.dexterity)/10)))
        self.maximum_damage = int(weapon_max * (1 + ((self.strength + self.dexterity)/10)))
        self.damage = random.randrange(self.minimum_damage, self.maximum_damage)
