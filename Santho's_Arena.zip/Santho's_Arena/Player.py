import random


class Player:
    def __init__(self, lv, exp, max_exp, life, mana, st, de, en, vt):
        self.level = lv
        self.xp = exp
        self.max_xp = max_exp

        self.maxlife = life
        self.life = self.maxlife
        self.maxmana = mana
        self.mana = self.maxmana

        self.strength = st
        self.dexterity = de
        self.magic = en
        self.vitality = vt

        # weapon mini damage = wMinD
        # weapon maxi damage = wMaxD

        self.minimum_damage = int(5 * (1 + ((self.strength + self.dexterity)/100)))
        self.maximum_damage = int(10 * (1 + ((self.strength + self.dexterity)/100)))
        self.damage = random.randrange(self.minimum_damage, self.maximum_damage)
