import random


class Opponent:
    def __init__(self, level):
        self.level = level
        self.life = 50 * self.level
        self.maxlife = 50 * self.level
        self.mana = 5 * self.level
        self.maxmana = 5 * self.level

        self.minimum_damage = 5 * self.level
        self.maximum_damage = 10 * self.level
        self.damage = random.randrange(self.minimum_damage, self.maximum_damage)


class Santho:
    def __init__(self, players_level):
        self.level = players_level

        self.maxlife = random.randrange(50, 101) * self.level
        self.life = self.maxlife

        self.maxmana = 5 * self.level
        self.mana = 5 * self.level

        self.strength = random.randrange(4, 10) * self.level
        self.dexterity = random.randrange(4, 10) * self.level

        self.minimum_damage = int(40 * (1 + ((self.strength + self.dexterity) / 100)))
        self.maximum_damage = int(100 * (1 + ((self.strength + self.dexterity) / 100)))
        self.damage = random.randrange(self.minimum_damage, self.maximum_damage)
