# Screen Resolution
SCREENWIDTH = 1280
SCREENHEIGHT = 720

# Color Palette
BLACK = (0, 0, 0)
BROWN = (150, 75, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (255, 0, 255)
ORANGE = (255, 127, 0)
CYAN = (0, 255, 255)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
LIGHTTAN = (220, 200, 170)