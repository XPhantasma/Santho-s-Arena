class Weapons:
    def __init__(self):
        # Assume the player fights with fists which is a VERY BAD IDEA
        self.minimum_damage = 1
        self.maximum_damage = 2
        self.cost = 0

    def dagger(self):
        self.minimum_damage = 2
        self.maximum_damage = 4
        self.cost = 10

    def shortsword(self):
        self.minimum_damage = 4
        self.maximum_damage = 8
        self.cost = 15

    def longsword(self):
        self.minimum_damage = 6
        self.maximum_damage = 16
        self.cost = 50

    def mage_staff(self):
        self.minimum_damage = 7
        self.maximum_damage = 11
        self.cost = 75

    def mace(self):
        self.minimum_damage = 10
        self.maximum_damage = 20
        self.cost = 150

    def sorcerer_staff(self):
        self.minimum_damage = 9
        self.maximum_damage = 14
        self.cost = 125

    def battle_axe(self):
        self.minimum_damage = 20
        self.maximum_damage = 30
        self.cost = 300

    def wizard_staff(self):
        self.minimum_damage = 14
        self.maximum_damage = 22
        self.cost = 250

    def astral_blade(self):
        self.minimum_damage = 40
        self.maximum_damage = 100
        self.cost = 1500

    def archmage_staff(self):
        self.minimum_damage = 25
        self.maximum_damage = 50
        self.cost = 1000

    def purchase_check(self, level, maxlife, purchasea, purchaseb):
        if level < 3 and maxlife > 10 and purchasea:
            self.dagger()
            return True
        elif level < 3 and maxlife > 15 and purchaseb:
            self.shortsword()
            return True
        elif level < 5 and maxlife > 50 and purchasea:
            self.longsword()
            return True
        elif level < 5 and maxlife > 75 and purchaseb:
            self.mage_staff()
            return True
        elif level < 7 and maxlife > 200 and purchasea:
            self.mace()
            return True
        elif level < 7 and maxlife > 125 and purchaseb:
            self.sorcerer_staff()
            return True
        elif level < 10 and maxlife > 300 and purchasea:
            self.battle_axe()
            return True
        elif level < 10 and maxlife > 250 and purchaseb:
            self.wizard_staff()
            return True
        elif level == 10 and maxlife > 1500 and purchasea:
            self.astral_blade()
            return True
        elif level == 10 and maxlife > 1000 and purchaseb:
            self.archmage_staff()
            return True


class Spells:
    def __init__(self):
        self.spell_min_damage = 0
        self.spell_max_damage = 0
        self.spell_life_cost = 0
        self.spell_base_cost = 0

    def fireball(self):
        self.spell_min_damage = 20
        self.spell_max_damage = 30
        self.spell_life_cost = 20
        self.spell_base_cost = 2

    def heal(self):
        self.spell_life_cost = 40
        self.spell_base_cost = 4

    def ice_bolt(self):
        self.spell_min_damage = 15
        self.spell_max_damage = 25
        self.spell_life_cost = 50
        self.spell_base_cost = 4

    def weaken(self):
        self.spell_life_cost = 60
        self.spell_base_cost = 3

    def lightning_bolt(self):
        self.spell_min_damage = 1
        self.spell_max_damage = 50
        self.spell_life_cost = 150
        self.spell_base_cost = 5

    def might(self):
        self.spell_life_cost = 100
        self.spell_base_cost = 6

    def guardian_shield(self):
        self.spell_life_cost = 250
        self.spell_base_cost = 7

    def apocolypse(self):
        self.spell_min_damage = 50
        self.spell_max_damage = 75
        self.spell_life_cost = 500
        self.spell_base_cost = 10

    def purchase_check(self, level, maxlife, buyoffspell, buydefspell):
        if level < 3 and maxlife > 20 and buyoffspell:
            self.fireball()
            return True

        elif level < 3 and maxlife > 40 and buydefspell:
            self.heal()
            return True

        elif level < 5 and maxlife > 50 and buyoffspell:
            self.ice_bolt()
            return True

        elif level < 5 and maxlife > 75 and buydefspell:
            self.weaken()
            return True

        elif level < 7 and maxlife > 200 and buyoffspell:
            self.lightning_bolt()
            return True

        elif level < 7 and maxlife > 125 and buydefspell:
            self.might()
            return True

        elif level < 10 and maxlife > 250 and buydefspell:
            self.guardian_shield()
            return True

        elif level == 10 and maxlife > 1000 and buyoffspell:
            self.apocolypse()
            return True
