class Weapons:
    pass

class Spells:
    pass
